export default function TriventaGroupWebsite() {
  const products = [
    {
      name: "Coca Cola 1.5L",
      price: "$1.990",
      image:
        "https://images.unsplash.com/photo-1629203851122-3726ecdf080e?q=80&w=800&auto=format&fit=crop",
    },
    {
      name: "Papas Fritas",
      price: "$2.490",
      image:
        "https://images.unsplash.com/photo-1566478989037-eec170784d0b?q=80&w=800&auto=format&fit=crop",
    },
    {
      name: "Leche Entera",
      price: "$1.390",
      image:
        "https://images.unsplash.com/photo-1550583724-b2692b85b150?q=80&w=800&auto=format&fit=crop",
    },
    {
      name: "Detergente",
      price: "$4.990",
      image:
        "https://images.unsplash.com/photo-1583947582886-f40ec95dd752?q=80&w=800&auto=format&fit=crop",
    },
  ];

  return (
    <div
      style={{
        fontFamily: "Inter, Arial, sans-serif",
        background: "#f8fafc",
        color: "#0f172a",
        margin: 0,
      }}
    >
      {/* NAVBAR */}
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "20px 70px",
          background: "white",
          position: "sticky",
          top: 0,
          zIndex: 999,
          boxShadow: "0 2px 15px rgba(0,0,0,0.06)",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 15 }}>
          <div
            style={{
              width: 60,
              height: 60,
              borderRadius: 18,
              background: "#16a34a",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 32,
              color: "white",
            }}
          >
            🛒
          </div>

          <div>
            <h1 style={{ margin: 0, fontSize: 30 }}>Triventa Group</h1>
            <p style={{ margin: 0, color: "#16a34a" }}>
              Tu mini market, a un click
            </p>
          </div>
        </div>

        <nav style={{ display: "flex", gap: 35, fontWeight: 600 }}>
          <a href="#" style={{ textDecoration: "none", color: "#0f172a" }}>
            Inicio
          </a>
          <a href="#" style={{ textDecoration: "none", color: "#0f172a" }}>
            Productos
          </a>
          <a href="#" style={{ textDecoration: "none", color: "#0f172a" }}>
            Planes
          </a>
          <a href="#" style={{ textDecoration: "none", color: "#0f172a" }}>
            Contacto
          </a>
        </nav>

        <button
          style={{
            background: "#16a34a",
            color: "white",
            border: "none",
            padding: "14px 26px",
            borderRadius: 14,
            fontWeight: 700,
            cursor: "pointer",
          }}
        >
          Comprar ahora
        </button>
      </header>

      {/* HERO */}
      <section
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          alignItems: "center",
          padding: "90px 70px",
          gap: 40,
          background:
            "linear-gradient(135deg, #ffffff 0%, #ecfdf5 50%, #dcfce7 100%)",
        }}
      >
        <div>
          <h2
            style={{
              fontSize: 74,
              lineHeight: 1,
              marginBottom: 30,
              fontWeight: 900,
            }}
          >
            TU MINI MARKET,
            <br />
            <span style={{ color: "#16a34a" }}>A UN CLICK</span>
          </h2>

          <p
            style={{
              fontSize: 22,
              color: "#475569",
              lineHeight: 1.7,
              marginBottom: 35,
            }}
          >
            Compra online en tu mini market de barrio de forma rápida, moderna y
            segura.
          </p>

          <div style={{ display: "flex", gap: 20 }}>
            <button
              style={{
                background: "#16a34a",
                color: "white",
                border: "none",
                padding: "18px 34px",
                borderRadius: 18,
                fontSize: 18,
                fontWeight: 700,
                cursor: "pointer",
                boxShadow: "0 10px 25px rgba(22,163,74,0.3)",
              }}
            >
              Comprar productos
            </button>

            <button
              style={{
                background: "white",
                border: "2px solid #16a34a",
                color: "#16a34a",
                padding: "18px 34px",
                borderRadius: 18,
                fontSize: 18,
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Ver planes
            </button>
          </div>

          <div
            style={{
              display: "flex",
              gap: 35,
              marginTop: 45,
              color: "#334155",
              fontWeight: 600,
            }}
          >
            <span>⚡ Envíos rápidos</span>
            <span>🔒 Pago seguro</span>
            <span>🥬 Productos frescos</span>
          </div>
        </div>

        <div style={{ position: "relative" }}>
          <img
            src="https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=1200&auto=format&fit=crop"
            alt="Mini market"
            style={{
              width: "100%",
              borderRadius: 40,
              boxShadow: "0 30px 70px rgba(0,0,0,0.18)",
              objectFit: "cover",
              height: 600,
            }}
          />

          <div
            style={{
              position: "absolute",
              bottom: -30,
              left: 30,
              background: "white",
              padding: 25,
              borderRadius: 25,
              boxShadow: "0 15px 40px rgba(0,0,0,0.15)",
            }}
          >
            <h3 style={{ marginTop: 0 }}>⭐ Oferta destacada</h3>
            <p style={{ marginBottom: 0 }}>Hasta 30% de descuento hoy.</p>
          </div>
        </div>
      </section>

      {/* PRODUCTOS */}
      <section style={{ padding: "100px 70px" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <h2 style={{ fontSize: 52, marginBottom: 15 }}>
            Productos Destacados
          </h2>
          <p style={{ color: "#64748b", fontSize: 20 }}>
            Todo lo que necesitas en un solo lugar.
          </p>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
            gap: 30,
          }}
        >
          {products.map((product, index) => (
            <div
              key={index}
              style={{
                background: "white",
                borderRadius: 30,
                overflow: "hidden",
                boxShadow: "0 15px 35px rgba(0,0,0,0.08)",
                transition: "0.3s",
              }}
            >
              <img
                src={product.image}
                alt={product.name}
                style={{ width: "100%", height: 250, objectFit: "cover" }}
              />

              <div style={{ padding: 25 }}>
                <h3 style={{ marginTop: 0, fontSize: 28 }}>{product.name}</h3>
                <p
                  style={{
                    color: "#16a34a",
                    fontWeight: 900,
                    fontSize: 34,
                  }}
                >
                  {product.price}
                </p>

                <button
                  style={{
                    width: "100%",
                    background: "#16a34a",
                    color: "white",
                    border: "none",
                    padding: "15px",
                    borderRadius: 14,
                    fontWeight: 700,
                    cursor: "pointer",
                  }}
                >
                  Agregar al carrito
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PLANES */}
      <section
        style={{
          padding: "100px 70px",
          background: "#dcfce7",
        }}
      >
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <h2 style={{ fontSize: 52, marginBottom: 15 }}>Planes</h2>
          <p style={{ color: "#475569", fontSize: 20 }}>
            Elige el plan ideal para tu mini market.
          </p>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
            gap: 35,
          }}
        >
          {[
            {
              name: "Plan Básico",
              price: "$18.990",
              features: ["Pedidos online", "Catálogo básico", "Soporte básico"],
            },
            {
              name: "Plan Intermedio",
              price: "$36.990",
              features: ["Gestión de stock", "Reportes", "Soporte prioritario"],
            },
            {
              name: "Plan Premium",
              price: "$59.990",
              features: ["Todas las funciones", "24/7", "Panel avanzado"],
            },
          ].map((plan, index) => (
            <div
              key={index}
              style={{
                background: "white",
                padding: 40,
                borderRadius: 35,
                boxShadow: "0 20px 40px rgba(0,0,0,0.1)",
                textAlign: "center",
              }}
            >
              <h3 style={{ fontSize: 34 }}>{plan.name}</h3>

              <div
                style={{
                  fontSize: 60,
                  fontWeight: 900,
                  color: "#16a34a",
                  margin: "25px 0",
                }}
              >
                {plan.price}
              </div>

              {plan.features.map((feature, i) => (
                <p key={i} style={{ fontSize: 18, color: "#475569" }}>
                  ✔ {feature}
                </p>
              ))}

              <button
                style={{
                  marginTop: 25,
                  width: "100%",
                  background: "#16a34a",
                  color: "white",
                  border: "none",
                  padding: "18px",
                  borderRadius: 16,
                  fontWeight: 700,
                  fontSize: 18,
                  cursor: "pointer",
                }}
              >
                Elegir plan
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* CONTACTO */}
      <section style={{ padding: "100px 70px", textAlign: "center" }}>
        <div
          style={{
            background: "linear-gradient(135deg, #16a34a, #22c55e)",
            color: "white",
            padding: "50px",
            borderRadius: "35px",
            marginBottom: "70px",
            boxShadow: "0 20px 50px rgba(22,163,74,0.25)",
          }}
        >
          <h2 style={{ fontSize: 48, marginTop: 0 }}>
            📍 Encuentra Mini Markets Cercanos
          </h2>

          <p
            style={{
              fontSize: 22,
              maxWidth: 900,
              margin: "20px auto",
              lineHeight: 1.7,
            }}
          >
            La plataforma detecta automáticamente tu ubicación para mostrar mini
            markets cercanos, productos disponibles y entregas rápidas en tu
            zona.
          </p>

          <button
            onClick={() => {
              if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition((position) => {
                  alert(
                    `Ubicación detectada correctamente.
Latitud: ${position.coords.latitude}
Longitud: ${position.coords.longitude}`
                  );
                });
              } else {
                alert("Tu navegador no permite geolocalización.");
              }
            }}
            style={{
              background: "white",
              color: "#16a34a",
              border: "none",
              padding: "18px 35px",
              borderRadius: 18,
              fontSize: 18,
              fontWeight: 800,
              cursor: "pointer",
              marginTop: 20,
            }}
          >
            Activar ubicación
          </button>
        </div>
        <h2 style={{ fontSize: 52, marginBottom: 20 }}>Contáctanos</h2>

        <p style={{ color: "#64748b", fontSize: 20, marginBottom: 50 }}>
          Estamos listos para ayudarte a modernizar tu negocio.
        </p>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
            gap: 30,
          }}
        >
          <div
            style={{
              background: "white",
              padding: 35,
              borderRadius: 30,
              boxShadow: "0 10px 30px rgba(0,0,0,0.08)",
            }}
          >
            <h3>📍 Mini Markets Cercanos</h3>
            <p>
              Encuentra mini markets cercanos automáticamente usando tu
              ubicación en tiempo real.
            </p>
          </div>

          <div
            style={{
              background: "white",
              padding: 35,
              borderRadius: 30,
              boxShadow: "0 10px 30px rgba(0,0,0,0.08)",
            }}
          >
            <h3>📧 Correo</h3>
            <p>contacto@triventagroup.cl</p>
          </div>

          <div
            style={{
              background: "white",
              padding: 35,
              borderRadius: 30,
              boxShadow: "0 10px 30px rgba(0,0,0,0.08)",
            }}
          >
            <h3>📍 Ubicación</h3>
            <p>Chile</p>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer
        style={{
          background: "#0f172a",
          color: "white",
          padding: "50px 70px",
          textAlign: "center",
        }}
      >
        <h2 style={{ marginTop: 0 }}>Triventa Group</h2>
        <p style={{ color: "#94a3b8" }}>
          Plataforma profesional para mini markets modernos.
        </p>
      </footer>
    </div>
  );
}
