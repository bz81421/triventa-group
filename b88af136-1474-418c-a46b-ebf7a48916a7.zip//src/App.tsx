// ===============================
// package.json
// ===============================
// Reemplaza tu package.json por esto:

/*
{
  "name": "triventa-group",
  "version": "1.0.0",
  "private": true,
  "dependencies": {
    "react": "18.2.0",
    "react-dom": "18.2.0",
    "react-scripts": "5.0.1"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build"
  },
  "browserslist": {
    "production": [
      ">0.2%",
      "not dead",
      "not op_mini all"
    ],
    "development": [
      "last 1 chrome version",
      "last 1 firefox version",
      "last 1 safari version"
    ]
  }
}
*/

// ===============================
// index.tsx
// ===============================
// Reemplaza tu index.tsx por esto:

/*
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
*/

// ===============================
// App.tsx
// ===============================

export default function App() {
  const products = [
    {
      name: "Coca Cola 1.5L",
      price: "$1.990",
      image:
        "https://images.unsplash.com/photo-1629203851122-3726ecdf080e?q=80&w=1200&auto=format&fit=crop",
    },
    {
      name: "Papas Fritas",
      price: "$2.490",
      image:
        "https://images.unsplash.com/photo-1566478989037-eec170784d0b?q=80&w=1200&auto=format&fit=crop",
    },
    {
      name: "Leche Entera",
      price: "$1.390",
      image:
        "https://images.unsplash.com/photo-1550583724-b2692b85b150?q=80&w=1200&auto=format&fit=crop",
    },
    {
      name: "Detergente",
      price: "$4.990",
      image:
        "https://images.unsplash.com/photo-1583947582886-f40ec95dd752?q=80&w=1200&auto=format&fit=crop",
    },
  ];

  const detectLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          alert(
            `Ubicación detectada correctamente.\n\nLatitud: ${position.coords.latitude}\nLongitud: ${position.coords.longitude}`
          );
        },
        () => {
          alert("No se pudo obtener la ubicación.");
        }
      );
    } else {
      alert("Tu navegador no soporta geolocalización.");
    }
  };

  return (
    <div
      style={{
        fontFamily: "Arial, sans-serif",
        background: "#f8fafc",
        color: "#0f172a",
      }}
    >
      {/* NAVBAR */}
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "20px 70px",
          background: "white",
          position: "sticky",
          top: 0,
          zIndex: 1000,
          boxShadow: "0 2px 15px rgba(0,0,0,0.08)",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 15 }}>
          <div
            style={{
              width: 60,
              height: 60,
              borderRadius: 18,
              background: "#16a34a",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "white",
              fontSize: 30,
            }}
          >
            🛒
          </div>

          <div>
            <h1 style={{ margin: 0, fontSize: 32 }}>Triventa Group</h1>
            <p style={{ margin: 0, color: "#16a34a" }}>
              Tu mini market, a un click
            </p>
          </div>
        </div>

        <nav style={{ display: "flex", gap: 30 }}>
          <a href="#" style={linkStyle}>
            Inicio
          </a>
          <a href="#productos" style={linkStyle}>
            Productos
          </a>
          <a href="#planes" style={linkStyle}>
            Planes
          </a>
          <a href="#contacto" style={linkStyle}>
            Contacto
          </a>
        </nav>
      </header>

      {/* HERO */}
      <section
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          alignItems: "center",
          padding: "90px 70px",
          gap: 40,
          background:
            "linear-gradient(135deg,#ffffff 0%,#ecfdf5 50%,#dcfce7 100%)",
        }}
      >
        <div>
          <h2
            style={{
              fontSize: 72,
              lineHeight: 1,
              marginBottom: 30,
            }}
          >
            TU MINI MARKET
            <br />
            <span style={{ color: "#16a34a" }}>A UN CLICK</span>
          </h2>

          <p
            style={{
              fontSize: 22,
              color: "#475569",
              lineHeight: 1.6,
            }}
          >
            Compra online de forma rápida, moderna y segura. Encuentra mini
            markets cercanos automáticamente.
          </p>

          <div style={{ display: "flex", gap: 20, marginTop: 35 }}>
            <button style={primaryButton}>Comprar ahora</button>

            <button style={secondaryButton} onClick={detectLocation}>
              Activar ubicación
            </button>
          </div>
        </div>

        <div>
          <img
            src="https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=1400&auto=format&fit=crop"
            alt="Mini Market"
            style={{
              width: "100%",
              borderRadius: 40,
              height: 600,
              objectFit: "cover",
              boxShadow: "0 25px 60px rgba(0,0,0,0.18)",
            }}
          />
        </div>
      </section>

      {/* PRODUCTOS */}
      <section id="productos" style={{ padding: "100px 70px" }}>
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <h2 style={{ fontSize: 52 }}>Productos Destacados</h2>
          <p style={{ color: "#64748b", fontSize: 20 }}>
            Productos frescos y ofertas diarias.
          </p>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
            gap: 30,
          }}
        >
          {products.map((product, index) => (
            <div
              key={index}
              style={{
                background: "white",
                borderRadius: 30,
                overflow: "hidden",
                boxShadow: "0 15px 35px rgba(0,0,0,0.08)",
              }}
            >
              <img
                src={product.image}
                alt={product.name}
                style={{
                  width: "100%",
                  height: 250,
                  objectFit: "cover",
                }}
              />

              <div style={{ padding: 25 }}>
                <h3 style={{ fontSize: 28 }}>{product.name}</h3>

                <p
                  style={{
                    fontSize: 34,
                    color: "#16a34a",
                    fontWeight: 900,
                  }}
                >
                  {product.price}
                </p>

                <button style={primaryButtonFull}>Agregar al carrito</button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PLANES */}
      <section
        id="planes"
        style={{
          padding: "100px 70px",
          background: "#dcfce7",
        }}
      >
        <div style={{ textAlign: "center", marginBottom: 60 }}>
          <h2 style={{ fontSize: 52 }}>Planes</h2>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit,minmax(300px,1fr))",
            gap: 35,
          }}
        >
          {[
            ["Plan Básico", "$18.990"],
            ["Plan Intermedio", "$36.990"],
            ["Plan Premium", "$59.990"],
          ].map((plan, index) => (
            <div
              key={index}
              style={{
                background: "white",
                padding: 40,
                borderRadius: 35,
                boxShadow: "0 20px 40px rgba(0,0,0,0.1)",
                textAlign: "center",
              }}
            >
              <h3 style={{ fontSize: 32 }}>{plan[0]}</h3>

              <div
                style={{
                  fontSize: 60,
                  color: "#16a34a",
                  fontWeight: 900,
                  margin: "25px 0",
                }}
              >
                {plan[1]}
              </div>

              <p>✔ Pedidos online</p>
              <p>✔ Gestión moderna</p>
              <p>✔ Plataforma profesional</p>

              <button style={primaryButtonFull}>Elegir plan</button>
            </div>
          ))}
        </div>
      </section>

      {/* CONTACTO */}
      <section
        id="contacto"
        style={{ padding: "100px 70px", textAlign: "center" }}
      >
        <h2 style={{ fontSize: 52 }}>Mini Markets Cercanos</h2>

        <p
          style={{
            color: "#64748b",
            fontSize: 20,
            maxWidth: 900,
            margin: "20px auto",
          }}
        >
          Usa tu ubicación para encontrar mini markets cercanos, productos
          disponibles y entregas rápidas.
        </p>

        <button style={primaryButton} onClick={detectLocation}>
          Buscar mini markets
        </button>
      </section>

      {/* FOOTER */}
      <footer
        style={{
          background: "#0f172a",
          color: "white",
          padding: "50px",
          textAlign: "center",
        }}
      >
        <h2>Triventa Group</h2>
        <p style={{ color: "#94a3b8" }}>
          Plataforma moderna para mini markets online.
        </p>
      </footer>
    </div>
  );
}

const linkStyle = {
  textDecoration: "none",
  color: "#0f172a",
  fontWeight: 700,
};

const primaryButton = {
  background: "#16a34a",
  color: "white",
  border: "none",
  padding: "18px 34px",
  borderRadius: 18,
  fontSize: 18,
  fontWeight: 700,
  cursor: "pointer",
};

const secondaryButton = {
  background: "white",
  color: "#16a34a",
  border: "2px solid #16a34a",
  padding: "18px 34px",
  borderRadius: 18,
  fontSize: 18,
  fontWeight: 700,
  cursor: "pointer",
};

const primaryButtonFull = {
  width: "100%",
  background: "#16a34a",
  color: "white",
  border: "none",
  padding: "16px",
  borderRadius: 16,
  fontSize: 18,
  fontWeight: 700,
  cursor: "pointer",
};
